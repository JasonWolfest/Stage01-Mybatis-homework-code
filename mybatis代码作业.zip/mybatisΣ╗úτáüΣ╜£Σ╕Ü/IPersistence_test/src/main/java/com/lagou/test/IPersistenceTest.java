package com.lagou.test;

import com.lagou.dao.IUserDao;
import com.lagou.io.Resources;
import com.lagou.pojo.UserInfo;
import com.lagou.sqlSession.SqlSession;
import com.lagou.sqlSession.SqlSessionFactory;
import com.lagou.sqlSession.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

public class IPersistenceTest {

    @Test
    public void insertTest() throws Exception {
        System.out.println("======== mysql版本为8.0 =========");
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        //调用
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);

        //查询所有用户
        System.out.println("===========打印所有用户==========");
        List<UserInfo> all = userDao.findAll();
        for (UserInfo user : all) {
            System.out.println(user);
        }

        //添加用户
        Integer userId = 6;
        UserInfo userInfo = new UserInfo(userId,"Test06");
        userDao.insert(userInfo);

        //查询所有用户
        System.out.println("");
        System.out.println("===========打印添加后所有用户==========");
        List<UserInfo> all2 = userDao.findAll();
        for (UserInfo user : all2) {
            System.out.println(user);
        }

    }

    @Test
    public void updateTest() throws Exception {
        System.out.println("======== mysql版本为8.0 =========");
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        //调用
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);

        //查询单个用户
        System.out.println("===========打印userId为6的用户==========");
        Integer userId = 6;
        UserInfo userInfo = new UserInfo(userId,"Test06");
        UserInfo addUser = userDao.findByCondition(userInfo);
        System.out.println(addUser);

        //更新添加用户
        UserInfo userInfo2 = new UserInfo(userId,"Helo");
        userDao.updateById(userInfo2);

        System.out.println("===========查询用户变更信息==========");
        UserInfo addUser2 = userDao.findByCondition(userInfo2);
        System.out.println(addUser2);

    }

    @Test
    public void deleteTest() throws Exception {
        System.out.println("======== mysql版本为8.0 =========");
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        //调用
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);

        //查询所有用户
        System.out.println("===========打印所有用户==========");
        List<UserInfo> all = userDao.findAll();
        for (UserInfo user : all) {
            System.out.println(user);
        }


        //删除用户
        Integer userId = 6;
        UserInfo userInfo = new UserInfo(userId,"Test06");
        userDao.deleteById(userInfo);


        //查询所有用户
        System.out.println("");
        System.out.println("===========打印删除后所有用户==========");
        List<UserInfo> all2 = userDao.findAll();
        for (UserInfo user : all2) {
            System.out.println(user);
        }

    }


}
