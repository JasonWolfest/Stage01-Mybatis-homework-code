package com.lagou.dao;

import com.lagou.pojo.UserInfo;

import java.util.List;

public interface IUserDao {

    //查询所有用户
    public List<UserInfo> findAll() throws Exception;


    //根据条件进行用户查询
    public UserInfo findByCondition(UserInfo user) throws Exception;

    public Integer insert(UserInfo user) throws Exception;

    public Integer deleteById(UserInfo user) throws Exception;

    public Integer updateById(UserInfo user) throws Exception;




}
