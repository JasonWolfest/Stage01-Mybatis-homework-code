
DROP TABLE IF EXISTS `userInfo`;
CREATE TABLE `userInfo` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=123403 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of orders
-- ----------------------------


INSERT INTO mybatis.userInfo (userName) VALUES 
('test04'),('Test01'),('Test02'),('test05'),('Helo');
